#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <math.h>
#include <time.h>
#include <argp.h>
#include <netcdf.h>
#include <jansson.h>
#include <libconfig.h>

int email_someone(const char *to_line, const char *from_line, const char *subject_line, const char *message_line) {

  FILE *email_connection = popen("/usr/lib/sendmail -t", "w");
  if (email_connection != NULL) {
    fprintf(email_connection, "To: %s\n", to_line);
    fprintf(email_connection, "From: %s\n", from_line);
    fprintf(email_connection, "Subject: %s\n\n", subject_line);
    fwrite(message_line, 1, strlen(message_line), email_connection);
    fwrite(".\n", 1, 2, email_connection);
    pclose(email_connection);
    return 0;
  }
  else {
    perror("Error sending mail!");
    return -1;
  }
}

void handle_error(int errid){
  if(errid == NC_NOERR) return;
  printf("%s\n", nc_strerror(errid));
  return;
}

static struct argp_option options[] = {
  {"configfile", 'c', "configuration_file",    0,   "Specify name of configuration file"},
  {"geojson",  'g', "input_geojson_file",      0,   "Specify name of input geoJSON file"},
  {"AlertSent_set",'s', "no|yes",              0,   "Set AlertSent variable to yes or no"}, 
  { 0 }
};

#define MAX_NAME 1024

struct arguments{
  char config_filename[MAX_NAME];
  char geojson_filename[MAX_NAME];
  char alert_set[MAX_NAME];
  short alert_option;  
};

static error_t parse_opt(int key, char *arg, struct argp_state *state){
  struct arguments *arguments = state->input;
  switch(key){
  case 'c':
    if (arg[0] != '-')
      strncpy(arguments->config_filename,arg,MAX_NAME);
    else {
      printf("arguments should not begin with a - sign.  Exiting...\n");
      exit(0);
    }
    break;
  case 'g':
    if (arg[0] != '-')
      strncpy(arguments->geojson_filename,arg,MAX_NAME);
    else {
      printf("arguments should not begin with a - sign.  Exiting...\n");
      exit(0);
    }
    break;
  case 's':

    if (arg[0] != '-')
      strncpy(arguments->alert_set,arg,MAX_NAME);
    else {
      printf("arguments should not begin with a - sign.  Exiting...\n");
      exit(0);
    }
    if ((strcmp(arg, "no") != 0) && (strcmp(arg, "yes") != 0)) {
      printf("arguments to -s should be yes or no. Exiting...\n");
      exit(0);
    }
    arguments->alert_option = 1;
    break;
    //case ARGP_KEY_END:
    //if(state->arg_num<1)
    // argp_usage(state);
    //break;
  
  default:
    return ARGP_ERR_UNKNOWN;
  }
  return 0;
}

static struct argp argp = {options,parse_opt,"$Id: email_notification.c,v 1.0 2018-04-19 13:34:22 elyons Exp $"};

int main(int argc, char* argv[])
{
  
  struct arguments arguments;
  arguments.config_filename[0] = '\0';
  arguments.alert_option = 0;
  arguments.geojson_filename[0] = '\0';
  int geojson_specified = 0;
  
  argp_parse(&argp,argc,argv,0,0,&arguments);
  
  if (arguments.geojson_filename[0] == '\0') {
    printf("No geojson input specified.  exiting...\n");
    exit(0); 
  }
  else {
    geojson_specified = 1;
  }

  /*locate and verify the config file*/
  char *en_home;
  if (arguments.config_filename[0] == '\0') {
    if ((en_home = getenv("EMAIL_NOTIFICATION_HOME")) != NULL) {
      sprintf(arguments.config_filename, "%s/email_notification_config.txt", en_home);
    }
    else {
      printf("Please specify config file with -c option or declare EMAIL_NOTIFICATION_HOME environment variable.  exiting...\n");
      exit(0);
    }
  }
  printf("config_filename: %s\n", arguments.config_filename);

  config_t en_config;
  config_init(&en_config);

  if (!config_read_file(&en_config, arguments.config_filename)) {
    printf("config file not found or contains errors.  exiting...\n");
    config_destroy(&en_config);
    exit(0);
  }

  const char *email_from;
  if(!config_lookup_string(&en_config, "email_from", &email_from)) {                                              
    printf("No email_from definition.  exiting...\n");
    exit(0);
  }
  else {
    printf("Email from: %s\n", email_from);
  }

  const char *data_type;
  if(!config_lookup_string(&en_config, "data_type", &data_type)) {
    printf("No data_type definition. exiting...\n");
    exit(0);
  }
  else {
    printf("Data type: %s\n", data_type);
  }

  const config_setting_t *email_to_arr;
  int ema;
  int num_email_recipients;
  double email_threshold;
  config_setting_t *email_to_params;

  email_to_params = config_lookup(&en_config, "email_to_params");
  
  if (email_to_params != NULL) {
      email_to_arr = config_setting_lookup(email_to_params, "email_to");
      if (email_to_arr != NULL) {
        num_email_recipients = config_setting_length(email_to_arr);
      }
      else {
        printf("No Email Recipients defined.  Exiting.\n");
	exit(0);
      }
  }

  const char *email_addresses[num_email_recipients];
      
  for (ema = 0; ema < num_email_recipients; ema++) {
    email_addresses[ema] = config_setting_get_string_elem(email_to_arr, ema);
    if (!email_addresses[ema]) {
      printf("Email Address %d not properly defined.  Exiting...\n", ema);
      exit(0);
    }
    else {
      printf("Emailing: %s\n", email_addresses[ema]);
    }
  }
  int em_thresh = 0;
  em_thresh = config_setting_lookup_float(email_to_params, "email_threshold", &email_threshold);
  if (em_thresh != CONFIG_TRUE) {
    printf("No email_threshold defined.  Exiting...");
    exit(0);
  }
  else {
    printf("Email threshold: %f\n", email_threshold);
  }
  
  if (geojson_specified) {
    json_t *json;
    json_error_t error;
    json_t *features;
    size_t num_features;
    int k;
    json_t *yes = json_string("yes");
    json_t *no = json_string("no");

    //Ok, with that, we're off...
    json = json_load_file(arguments.geojson_filename, 0, &error);
    if(!json) {
      printf("JSON ERROR: %s\n", error.text);
      exit(0);
    }

    if (!json_is_object(json)){
      printf("json type: %d\n", json_typeof(json));
      printf("geoJSON file does not contain an object.  Please try another geoJSON file.  Exiting...\n");
      exit(0);
    }

    features = json_object_get(json, "features");
    if (features == NULL) {
      printf("geoJSON file does not contain the necessary \"features\" field.  Exiting...\n");
      exit(0);
    }
    if (!json_is_array(features)) {
      printf("\"features\" field is not an array.  Exiting...\n");
      exit(0);
    }

    num_features = json_array_size(features);
    if (num_features < 1) {
      printf("no features present in this geoJSON.  Exiting...\n");
      exit(0);
    }
    
    for (k=0; k<num_features; k++) {
      json_t *this_feature = json_array_get(features, k);
      if (json_is_object(this_feature)) {
	json_t *this_feature_type = json_object_get(this_feature, "type");
	if (json_is_string(this_feature_type)) { 
	  if (strcmp(json_string_value(this_feature_type), "Feature") == 0) {
	    json_t *this_feature_properties = json_object_get(this_feature, "properties");

	    if(arguments.alert_option == 1) {
	      if (strcmp(arguments.alert_set, "yes") == 0) {
		int setAlert = json_object_set(this_feature_properties, "AlertSent", yes);
                if (setAlert == -1) {
                  printf("Failed to set AlertSent property\n");
                }
	      }
	      else if (strcmp(arguments.alert_set, "no") == 0) {
		int setAlert = json_object_set(this_feature_properties, "AlertSent", no);
                if (setAlert == -1) {
                  printf("Failed to set AlertSent property\n");
                }
	      }
	      else {
		printf("argument not recognized. exiting...");
		exit(0);
	      }
	    }
	    else {
	      json_t *this_feature_id = json_object_get(this_feature_properties, "siteID");
	      json_t *this_feature_location = json_object_get(this_feature_properties, "NAME");
	      json_t *this_feature_alert = json_object_get(this_feature_properties, "AlertSent");
	      json_t *this_feature_time = json_object_get(this_feature_properties, "Timestamp");
	      json_t *this_feature_data = json_object_get(this_feature_properties, data_type);
	      
	      if(json_real_value(this_feature_data) > email_threshold) {
		if(strcmp(json_string_value(this_feature_alert), "no") == 0) {
		  
		  char email_subject[256];
		  sprintf(email_subject, "CASA automated notification for %s\n", json_string_value(this_feature_location));
		  char email_message[1028];
		  sprintf(email_message, "siteID: %s\nsiteLocation: %s\n%s: %.2f\ntimestamp: %s\n\n\nTo be removed from this mailing list, please send email to elyons@cs.umass.edu", json_string_value(this_feature_id), json_string_value(this_feature_location), data_type, json_real_value(this_feature_data), json_string_value(this_feature_time));
		  
		  for (ema = 0; ema < num_email_recipients; ema++) {
		    email_someone(email_addresses[ema], email_from, email_subject, email_message);
		  }
		  
		  int setAlert = json_object_set(this_feature_properties, "AlertSent", yes);    
		  if (setAlert == -1) {
		    printf("Failed to set AlertSent property\n");
		  }
		}
	      }
	    }
	  }
	}
      }
    }
    int dumpstatus = json_dump_file(json, arguments.geojson_filename, 0);
    if (dumpstatus == -1) {
      printf("GeoJSON file dump failed!\n");
    }
  }
  
  return 0;
}

